# Meteora Touch Fix 1

First device-test build, 2026-09-28. Not yet tested on an iOS device.
Upstream: https://github.com/iKilledAppl3/Meteora
Base commit: 8a04469d9f691db0602e1d5a1adf7bbb42b535de
Original authors: iKilledAppl3 and Skittyblock. Original MIT license included.
Package identifier: com.ikilledappl3.meteora
Package version: 1.0-13+touchfix1
Architectures: armv7 and arm64. Deployment target: iOS 10.0.

## Changes

- Own and reuse one NC, CC and optional two-finger gesture set per lock-screen
  view. NC is registered only while active, with explicit removal on window
  detachment, controller disappearance, unlock, disabling and destruction.
- Perform presentation once at the beginning of a pan; reject callbacks outside
  the enabled, visible, locked context.
- Reuse the camera icon, artwork, media controller, media blur and notification
  view. Replace shared view pointers with per-instance ownership and balance
  allocations. Remove observers and release controllers on destruction.
- Request artwork on appearance/media changes rather than every layout, decode
  once, run UI updates on the main thread and coalesce overlapping requests.
- Correct the Darwin preference callback signature and preference allocations.
- Existing authentication, passcode, slide-to-unlock and dashboard hooks are
  preserved. This does not claim to repair unrelated upstream problems.
- No diagnostic log files, background polling, or periodic resprings.

## Installation and test

Install the deb over Meteora using Filza or a package manager, then respring.
It uses the same package identifier and preference domain. It contains no
user-preference file and does not reset settings. Dependencies remain Substrate
and Cephei; installation is restricted to iOS 10.x. Keep the previous installer
if you want to roll back: reinstall it and respring.

Test slide-to-unlock, passcode, Touch ID (if used), NC, CC, notifications, camera,
two-finger lock (if enabled), and music artwork/controls. Repeat 20-30 normal
lock/unlock cycles, including opening NC and CC, then use the phone past the
usual onset time. Check both the Home Screen and lock screen. A passing test
means responsiveness stays stable and those functions continue to work.

If it still deteriorates, report device model, exact iOS version, package version,
time to onset, whether apps are affected, whether edge swipes or all taps are
affected, and whether music/notifications were involved. Then use an instrumented
build to measure live recognizers/views and memory rather than guessing further.

## Rebuilding

Run build_touchfix.sh with MTO_TOOLCHAIN_BIN, MTO_SDK and MTO_THEOS set.
Built here with clang 11.1.0 (L1ghtmann toolchain), cctools/ldid, Theos Logos/vendor
headers and stubs, and iPhoneOS9.3.sdk for its 32/64-bit libraries. The deployment
target is explicitly iOS 10.0. Both the tweak and preference binary are compiled
from source, merged with lipo and ad-hoc signed. Package compression is gzip for
older dpkg compatibility. Resources are unmodified files from upstream's staged
Library directory, without its prebuilt executables.

The source archive is installed at
/usr/share/doc/meteora-touchfix/source.tar.xz.
