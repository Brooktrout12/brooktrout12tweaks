#import "BSAnimationEffects.h"
#include <math.h>

static void BSKeyframes(CALayer *layer, NSString *keyPath, NSArray *values,
                         NSArray<NSNumber *> *times, double duration, NSString *curve) {
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:keyPath];
    animation.values = values;
    animation.keyTimes = times;
    animation.duration = duration;
    animation.calculationMode = kCAAnimationLinear;
    NSMutableArray *curves = [NSMutableArray arrayWithCapacity:times.count - 1];
    for (NSUInteger i = 1; i < times.count; ++i)
        [curves addObject:[CAMediaTimingFunction functionWithName:curve]];
    animation.timingFunctions = curves;
    // Set the final model value first so removal cannot flash the full image.
    [layer setValue:values.lastObject forKeyPath:keyPath];
    [layer addAnimation:animation forKey:[@"BlurSleep." stringByAppendingString:keyPath]];
}

static void BSOriginalBlur(CALayer *layer, double duration) {
    // Same radius, opacity and timing as the user-confirmed 1.0.2 renderer.
    layer.opacity = 0;
    [layer setValue:@36 forKeyPath:@"filters.sleepBlur.inputRadius"];
    CABasicAnimation *blur = [CABasicAnimation animationWithKeyPath:@"filters.sleepBlur.inputRadius"];
    blur.fromValue = @0; blur.toValue = @36;
    blur.duration = duration;
    blur.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    CABasicAnimation *fade = [CABasicAnimation animationWithKeyPath:@"opacity"];
    fade.fromValue = @1; fade.toValue = @0;
    fade.duration = duration;
    fade.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [layer addAnimation:blur forKey:@"BlurSleep.blur"];
    [layer addAnimation:fade forKey:@"BlurSleep.fade"];
}

static void BSCRT(UIImageView *image, UIView *container, double duration) {
    CALayer *layer = image.layer;
    CGFloat thin = 1.5 / MAX(1.0, image.bounds.size.height);
    // Symmetric compression about the default center anchor: top and bottom
    // meet first. Width contracts only once the image is a horizontal line.
    BSKeyframes(layer,@"transform.scale.y",@[@1,@0.96,@(thin),@(thin),@(thin)],
        @[@0,@0.12,@0.62,@0.82,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
    BSKeyframes(layer,@"transform.scale.x",@[@1,@1,@0.75,@0.001],
        @[@0,@0.66,@0.82,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
    BSKeyframes(layer,@"opacity",@[@1,@1,@0,@0],
        @[@0,@0.60,@0.76,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);

    // A narrow phosphor-like glow, never a full-screen white flash.
    CALayer *line = [CALayer layer];
    line.name = @"BlurSleep.CRTGlow";
    line.bounds = CGRectMake(0,0,container.bounds.size.width,1.5);
    line.position = CGPointMake(CGRectGetMidX(container.bounds),CGRectGetMidY(container.bounds));
    line.backgroundColor = UIColor.whiteColor.CGColor;
    line.cornerRadius = 0.75;
    line.shadowColor = UIColor.whiteColor.CGColor;
    line.shadowOpacity = 0.85;
    line.shadowRadius = 6;
    line.shadowOffset = CGSizeZero;
    [container.layer addSublayer:line];
    BSKeyframes(line,@"opacity",@[@0,@0,@1,@0.65,@0],
        @[@0,@0.56,@0.68,@0.92,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
    BSKeyframes(line,@"transform.scale.x",@[@1,@1,@0.002,@0.002],
        @[@0,@0.68,@0.94,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
}

static void BSIris(UIImageView *image, double duration) {
    CGSize size = image.bounds.size;
    // A circle as large as the diagonal includes all four screen corners.
    CGFloat diameter = hypot(size.width,size.height) + 2;
    CALayer *mask = [CALayer layer];
    mask.name = @"BlurSleep.IrisMask";
    mask.bounds = CGRectMake(0,0,diameter,diameter);
    mask.position = CGPointMake(CGRectGetMidX(image.bounds),CGRectGetMidY(image.bounds));
    mask.cornerRadius = diameter / 2;
    mask.backgroundColor = UIColor.blackColor.CGColor;
    mask.masksToBounds = YES;
    image.layer.mask = mask;
    BSKeyframes(mask,@"transform.scale",@[@1,@0.70,@0.001],
        @[@0,@0.4,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
    BSKeyframes(image.layer,@"opacity",@[@1,@1,@0],
        @[@0,@0.94,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
}

static void BSShrink(UIImageView *image, double duration) {
    BSKeyframes(image.layer,@"transform.scale",@[@1,@0.88,@0.001],
        @[@0,@0.22,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
    BSKeyframes(image.layer,@"cornerRadius",@[@0,@28,@28],
        @[@0,@0.25,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
    BSKeyframes(image.layer,@"opacity",@[@1,@1,@0],
        @[@0,@0.72,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
}

static void BSSlide(UIImageView *image, UIView *container, double duration) {
    CGFloat y = image.layer.position.y;
    BSKeyframes(image.layer,@"position.y",@[@(y),@(y + container.bounds.size.height * 1.05)],
        @[@0,@1],duration,kCAMediaTimingFunctionEaseIn);
    BSKeyframes(image.layer,@"opacity",@[@1,@1,@0],
        @[@0,@0.72,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
}

static void BSFlip(UIImageView *image, double duration) {
    CGFloat distance = MAX(image.bounds.size.width,image.bounds.size.height) * 2;
    CATransform3D perspective = CATransform3DIdentity;
    perspective.m34 = -1.0 / MAX(1.0,distance);
    CATransform3D middle = CATransform3DRotate(perspective,M_PI * 0.22,0,1,0);
    middle = CATransform3DScale(middle,0.92,0.92,1);
    CATransform3D end = CATransform3DRotate(perspective,M_PI_2,0,1,0);
    end = CATransform3DScale(end,0.8,0.8,1);
    image.layer.doubleSided = NO;
    BSKeyframes(image.layer,@"transform",@[[NSValue valueWithCATransform3D:perspective],
        [NSValue valueWithCATransform3D:middle],[NSValue valueWithCATransform3D:end]],
        @[@0,@0.55,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
    BSKeyframes(image.layer,@"opacity",@[@1,@1,@0],
        @[@0,@0.65,@1],duration,kCAMediaTimingFunctionEaseInEaseOut);
}

void BSApplyAnimationStyle(UIImageView *image, UIView *container,
                           BSAnimationStyle style, double duration) {
    container.clipsToBounds = YES;
    switch (BSNormalizeStyle(style)) {
        case BSStyleCRTTelevision: BSCRT(image,container,duration); break;
        case BSStyleIrisClose: BSIris(image,duration); break;
        case BSStyleShrink: BSShrink(image,duration); break;
        case BSStyleSlideDown: BSSlide(image,container,duration); break;
        case BSStyleCardFlip: BSFlip(image,duration); break;
        default: BSOriginalBlur(image.layer,duration); break;
    }
}
