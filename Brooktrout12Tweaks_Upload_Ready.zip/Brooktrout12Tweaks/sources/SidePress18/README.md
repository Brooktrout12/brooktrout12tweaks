# Side Press 18 1.0.1 — iOS 17 and 18

By Brooktrout12. Update from 1.0.0. Package ID: `com.brooktrout12.sidepress18`.

## Compatibility update

Adds a separate Side Button Click Speed selector in the tweak settings on Touch ID devices. The native Accessibility click-speed page is left for the Home button. Face ID devices retain the existing Side Button settings integration. Unlock status text includes Touch ID. Authentication, secure-intent priority, cancellation, and callback ownership remain.

The DEB dependency is `firmware (>= 17.0), firmware (<< 19.0)`. Runtime major-version checks accept 17 and 18, and both arm64/arm64e binaries target iOS 17.0. The package name, identifier, and existing preference domains are retained for normal upgrades.

## Install

Open `com.brooktrout12.sidepress18_1.0.1_iphoneos-arm64.deb` in the existing rootless package manager and install it as an update. Let the package manager resolve the dependencies listed in `control`; no firmware-force option is required for iOS 17.6.1. Respring after SpringBoard tweaks and reopen Settings for preference changes. The archive contains no automatic installer.

## Device check

On the SE, select Faster/Fastest in SidePress settings and confirm Home button speed stays unchanged. Test single/double presses, native default, screenshot, Camera, app actions, and Require Unlock with Touch ID/passcode. On iOS 18 Face ID hardware, check the existing Accessibility integration.

Compatibility review used the iOS **17.0.3** headers at https://github.com/MTACS/iOS-17-Runtime-Headers and the original projects' iOS 18 references. The downloaded iOS 17 header archive SHA-256 is `5d2634d56c32b829f9ec0d816a695a55b225beda4abc525e9be1ef7cb2cf17d2`. This is interface evidence, not execution of iOS 17.6.1. Runtime selector/signature guards remain where the original project supplies them. Unsupported private interfaces may leave a feature inactive rather than force a mismatched hook.

No physical iPhone was connected. **The new release has not been device-tested on iOS 17 or iOS 18.** The priority acceptance device is iPhone SE (2020/A13), iOS 17.6.1, with the user's existing rootless Dopamine setup. All iOS 17.x and 18.x are admitted by the package/runtime range; behavior on every model and point release cannot be certified by static checks. Hardware tests and interactions with other installed tweaks remain outstanding.

## Source and evidence

This archive contains the exact updated project sources, original assets/licenses, fresh matching debug symbols, and retained regression scripts. `IOS17-18.patch` compares the edited implementation/build/test files with the original source ZIP. `BUILD-IOS17-18.md` gives current build commands. `validation/` contains current results and the distributed DEB hash. `source-manifest.json` hashes every other archived file.

Baseline usage, implementation details, earlier diagnoses, and old reports are preserved in `history/baseline-1.0.0/`. Those historical version numbers and results do not describe the new binary.
