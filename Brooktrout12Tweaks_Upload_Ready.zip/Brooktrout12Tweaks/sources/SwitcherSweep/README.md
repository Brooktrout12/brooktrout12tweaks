# Switcher Sweep 1.0.8 — iOS 17 and 18

By Brooktrout12. Update from 1.0.7. Package ID: `com.brooktrout12.switchersweep`.

## Compatibility update

Retains the existing guarded switcher transitions, sweep policy, and safe-area button placement. The SE uses the same native switcher hooks; no fixed screen height was introduced.

The DEB dependency is `firmware (>= 17.0), firmware (<< 19.0)`. Runtime major-version checks accept 17 and 18, and both arm64/arm64e binaries target iOS 17.0. The package name, identifier, and existing preference domains are retained for normal upgrades.

## Install

Open `com.brooktrout12.switchersweep_1.0.8_iphoneos-arm64.deb` in the existing rootless package manager and install it as an update. Let the package manager resolve the dependencies listed in `control`; no firmware-force option is required for iOS 17.6.1. Respring after SpringBoard tweaks and reopen Settings for preference changes. The archive contains no automatic installer.

## Device check

Open the switcher with the Home button, sweep from a settled view and during entry, cancel once, and check the button on the smaller SE screen and with Reduce Motion.

Compatibility review used the iOS **17.0.3** headers at https://github.com/MTACS/iOS-17-Runtime-Headers and the original projects' iOS 18 references. The downloaded iOS 17 header archive SHA-256 is `5d2634d56c32b829f9ec0d816a695a55b225beda4abc525e9be1ef7cb2cf17d2`. This is interface evidence, not execution of iOS 17.6.1. Runtime selector/signature guards remain where the original project supplies them. Unsupported private interfaces may leave a feature inactive rather than force a mismatched hook.

No physical iPhone was connected. **The new release has not been device-tested on iOS 17 or iOS 18.** The priority acceptance device is iPhone SE (2020/A13), iOS 17.6.1, with the user's existing rootless Dopamine setup. All iOS 17.x and 18.x are admitted by the package/runtime range; behavior on every model and point release cannot be certified by static checks. Hardware tests and interactions with other installed tweaks remain outstanding.

## Source and evidence

This archive contains the exact updated project sources, original assets/licenses, fresh matching debug symbols, and retained regression scripts. `IOS17-18.patch` compares the edited implementation/build/test files with the original source ZIP. `BUILD-IOS17-18.md` gives current build commands. `validation/` contains current results and the distributed DEB hash. `source-manifest.json` hashes every other archived file.

Baseline usage, implementation details, earlier diagnoses, and old reports are preserved in `history/baseline-1.0.7/`. Those historical version numbers and results do not describe the new binary.
